# Sign Language > sign-language-v1
https://universe.roboflow.com/sign-language-detection-0oizv/sign-language-a6dry

Provided by a Roboflow user
License: CC BY 4.0

